package com.cg.lab.six;

public class AgeExceptions extends Exception {
	public AgeExceptions(String message) {
		super(message);
	}
}
