package com.cg.lab.six;

import java.util.InputMismatchException;
import java.util.Scanner;

public class PersonMain {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		Person person = new Person();

		System.out.println("Person Details");
		System.out.println("-------------");

		System.out.println(" Enter the First Name");
		String first = "";
		try {

			first = scanner.nextLine();
			person.setFirstName(first);
		} catch (InputMismatchException e) {
			System.out.println(e.getMessage());
		}
		person.setFirstName(first);
		if (!first.isEmpty()) {

		} else {
			System.err.println("First Name should not be blank");
			System.exit(0);
		}
		System.out.println("Enter the last name");
		String last = "";
		try {

			last = scanner.nextLine();
			person.setLastName(last);
		} catch (InputMismatchException e) {
			System.err.println("is empty");
		}
		if (!last.isEmpty()) {

		} else {
			System.err.println(" Last Name should not be blank");
			System.exit(0);
		}
		System.out.println("Enter the gender");
		char gender = scanner.next().charAt(0);

		person.setGender(gender);
		System.out.println("First Name :" + person.getFirstName());
		System.out.println("Last Name :" + person.getLastName());
		System.out.println("Gender :" + person.getGender());

	}

}
